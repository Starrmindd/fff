<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    include 'config.php';

    // collect form data
    $name = $_POST["name"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];
    $date = $_POST["date"];
    $time = $_POST["time"];
    $terID = isset($_POST["terID"]) ? $_POST["terID"] : "";
    $message = $_POST["message"];

    // Validate form data (you can add more validation if needed)
    if (empty($name) || empty($email) || empty($phone) || empty($date) || empty($time) || empty($message)) {
        echo "Error: All fields are required.";
        exit;
    }

    // Insert data into the database
    $sql = "INSERT INTO book_me (name, email, phone, date, time, terID, message) VALUES ('$name', '$email', '$phone', '$date', '$time', '$terID', '$message')";

    if ($conn->query($sql) === TRUE) {
        echo "OK"; // Indicate success to the JavaScript
    } else {
        echo "Error: Unable to insert data into the database. Please try again later.";
    }

    $conn->close();
}
?>
