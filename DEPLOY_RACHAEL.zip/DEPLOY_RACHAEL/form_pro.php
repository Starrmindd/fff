

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    include 'config.php';

    // collect form data
    $name = $_POST["name"];
    $email = $_POST["email"];
    $subject = $_POST["subject"];
    $message = $_POST["message"];

    // Validate form data (you can add more validation if needed)
    if (empty($name) || empty($email) || empty($subject) || empty($message)) {
        echo "Error: All fields are required.";
        exit;
    }

    // Insert data into the database
    $sql = "INSERT INTO contact_me (name, email, subject, message) VALUES ('$name', '$email', '$subject', '$message')";

    if ($conn->query($sql) === TRUE) {
        echo "OK"; // Indicate success to the JavaScript
    } else {
        echo "Error: Unable to insert data into the database. Please try again later.";
    }

    $conn->close();
}
?>
