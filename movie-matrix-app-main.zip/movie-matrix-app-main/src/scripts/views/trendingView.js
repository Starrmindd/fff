import mainView from "./mainView";

/**
 * Handle's the rendering of trending movie/tv show cards in the page.
 *
 * Extends of {@link mainView}
 */
class trendingView extends mainView {
  _title = "Trending";
}

export default new trendingView();
